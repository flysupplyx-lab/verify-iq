// VerifyIQ Chrome Extension - Popup Script
// Handles tab switching, API calls, and result rendering

const DEFAULT_API_URL = 'http://localhost:3000';

// ===== STATE =====
let currentTab = 'email';
let settings = {
    apiUrl: DEFAULT_API_URL,
    apiKey: '',
};

// ===== INIT =====
document.addEventListener('DOMContentLoaded', async () => {
    // Load settings
    try {
        const stored = await chrome.storage.local.get(['apiUrl', 'apiKey']);
        if (stored.apiUrl) settings.apiUrl = stored.apiUrl;
        if (stored.apiKey) settings.apiKey = stored.apiKey;
        document.getElementById('apiUrl').value = settings.apiUrl;
        document.getElementById('apiKey').value = settings.apiKey;
    } catch (e) {
        // Running outside extension context (dev mode)
        console.log('Running in dev mode');
    }

    // Tab switching
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    // Email verification
    document.getElementById('verifyBtn').addEventListener('click', verifyEmail);
    document.getElementById('emailInput').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') verifyEmail();
    });

    // AI detection
    document.getElementById('analyzeBtn').addEventListener('click', analyzeAI);
    document.getElementById('aiTextInput').addEventListener('input', updateCharCount);

    // Settings
    document.getElementById('settingsBtn').addEventListener('click', toggleSettings);
    document.getElementById('saveSettings').addEventListener('click', saveSettings);

    // Check if there's selected text from the page
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const [result] = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => window.getSelection().toString(),
        });
        if (result?.result && result.result.length > 50) {
            switchTab('ai');
            document.getElementById('aiTextInput').value = result.result;
            updateCharCount();
        }
    } catch (e) {
        // Not in extension context or no permission
    }
});

// ===== TAB SWITCHING =====
function switchTab(tabName) {
    currentTab = tabName;

    // Update tab buttons
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');

    // Update panels
    document.getElementById('emailPanel').classList.toggle('active', tabName === 'email');
    document.getElementById('aiPanel').classList.toggle('active', tabName === 'ai');
    document.getElementById('settingsPanel').style.display = 'none';
}

function toggleSettings() {
    const panel = document.getElementById('settingsPanel');
    const isVisible = panel.style.display !== 'none';

    if (isVisible) {
        panel.style.display = 'none';
        document.getElementById(`${currentTab}Panel`).classList.add('active');
    } else {
        document.getElementById('emailPanel').classList.remove('active');
        document.getElementById('aiPanel').classList.remove('active');
        panel.style.display = 'flex';
    }
}

async function saveSettings() {
    settings.apiUrl = document.getElementById('apiUrl').value.replace(/\/$/, '');
    settings.apiKey = document.getElementById('apiKey').value.trim();

    try {
        await chrome.storage.local.set(settings);
    } catch (e) {
        // Dev mode
    }

    // Show saved feedback
    const btn = document.getElementById('saveSettings');
    btn.textContent = '✓ Saved!';
    btn.style.background = 'linear-gradient(135deg, #22c55e, #06b6d4)';
    setTimeout(() => {
        btn.textContent = 'Save Settings';
        btn.style.background = '';
    }, 2000);
}

// ===== API HELPER =====
async function apiCall(endpoint, body) {
    const headers = {
        'Content-Type': 'application/json',
        'X-Source': 'extension',
    };

    if (settings.apiKey) {
        headers['X-Api-Key'] = settings.apiKey;
    }

    const response = await fetch(`${settings.apiUrl}${endpoint}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        const error = await response.json().catch(() => ({ error: 'Server error' }));
        throw new Error(error.message || error.error || `HTTP ${response.status}`);
    }

    return response.json();
}

// ===== EMAIL VERIFICATION =====
async function verifyEmail() {
    const email = document.getElementById('emailInput').value.trim();
    if (!email) {
        document.getElementById('emailInput').focus();
        return;
    }

    // Show loading
    document.getElementById('emailResult').style.display = 'none';
    document.getElementById('emailLoading').style.display = 'flex';

    try {
        const result = await apiCall('/api/verify-email', { email });
        renderEmailResult(result);
    } catch (error) {
        renderEmailError(error.message);
    }
}

function renderEmailResult(result) {
    document.getElementById('emailLoading').style.display = 'none';
    const container = document.getElementById('emailResult');
    container.style.display = 'block';

    // Score ring
    const scoreValue = document.getElementById('emailScoreValue');
    scoreValue.textContent = result.score;

    const circle = document.getElementById('emailScoreCircle');
    const circumference = 2 * Math.PI * 52;
    const offset = circumference - (result.score / 100) * circumference;

    // Set color based on score
    let color;
    if (result.score >= 80) color = '#22c55e';
    else if (result.score >= 60) color = '#f59e0b';
    else color = '#ef4444';

    circle.style.stroke = color;
    setTimeout(() => {
        circle.style.strokeDashoffset = offset;
    }, 100);

    // Verdict badge
    const verdict = document.getElementById('emailVerdict');
    verdict.textContent = result.verdict.replace(/_/g, ' ');
    verdict.className = `verdict-badge ${result.verdict}`;

    // Checks
    const checksEl = document.getElementById('emailChecks');
    checksEl.innerHTML = '';

    const checksConfig = [
        { key: 'syntax', label: 'Syntax', passCheck: c => c.valid },
        { key: 'dns', label: 'Mail Server (MX)', passCheck: c => c.valid },
        { key: 'disposable', label: 'Disposable Check', passCheck: c => !c.is_disposable },
        { key: 'typo', label: 'Typo Check', passCheck: c => !c.has_typo },
        { key: 'role_based', label: 'Role-Based', passCheck: c => !c.is_role_based },
        { key: 'domain', label: 'Domain Auth (SPF/DMARC)', passCheck: c => c.has_spf },
        { key: 'local_part', label: 'Local Part Quality', passCheck: c => c.quality !== 'suspicious' },
        { key: 'free_provider', label: 'Provider Type', passCheck: () => true },
    ];

    for (const config of checksConfig) {
        const check = result.checks[config.key];
        if (!check) continue;

        const passed = config.passCheck(check);
        const isWarning = config.key === 'free_provider' && check.is_free;
        const status = passed && !isWarning ? 'pass' : (isWarning ? 'warn' : (config.key === 'role_based' && check.is_role_based ? 'warn' : 'fail'));
        const icon = status === 'pass' ? '✓' : status === 'warn' ? '!' : '✗';

        const detail = check.description || check.reason ||
            (config.key === 'free_provider' ? (check.is_free ? 'Free email provider' : 'Business domain') : '');

        checksEl.innerHTML += `
      <div class="check-item">
        <div class="check-icon ${status}">${icon}</div>
        <div class="check-info">
          <div class="check-name">${config.label}</div>
          <div class="check-detail">${detail}</div>
        </div>
      </div>
    `;
    }

    // Suggestions
    const suggestionsEl = document.getElementById('emailSuggestions');
    if (result.suggestions && result.suggestions.length > 0) {
        suggestionsEl.style.display = 'block';
        suggestionsEl.innerHTML = `<strong>💡 Suggestions</strong>${result.suggestions.join('<br>')}`;
    } else {
        suggestionsEl.style.display = 'none';
    }
}

function renderEmailError(message) {
    document.getElementById('emailLoading').style.display = 'none';
    const container = document.getElementById('emailResult');
    container.style.display = 'block';

    document.getElementById('emailScoreValue').textContent = '!';
    document.getElementById('emailVerdict').textContent = 'Error';
    document.getElementById('emailVerdict').className = 'verdict-badge invalid';

    const checksEl = document.getElementById('emailChecks');
    checksEl.innerHTML = `
    <div class="check-item">
      <div class="check-icon fail">✗</div>
      <div class="check-info">
        <div class="check-name">Connection Error</div>
        <div class="check-detail">${message}</div>
      </div>
    </div>
    <div class="check-item">
      <div class="check-icon warn">!</div>
      <div class="check-info">
        <div class="check-name">Make sure the API server is running</div>
        <div class="check-detail">Run: npm start (in the project directory)</div>
      </div>
    </div>
  `;
}

// ===== AI DETECTION =====
function updateCharCount() {
    const text = document.getElementById('aiTextInput').value;
    document.getElementById('charCount').textContent = `${text.length} chars`;
}

async function analyzeAI() {
    const text = document.getElementById('aiTextInput').value.trim();
    if (!text || text.length < 50) {
        const input = document.getElementById('aiTextInput');
        input.style.borderColor = '#ef4444';
        input.placeholder = 'Please paste at least 50 characters of text...';
        setTimeout(() => {
            input.style.borderColor = '';
            input.placeholder = 'Paste text to analyze for AI content...';
        }, 2000);
        return;
    }

    // Show loading
    document.getElementById('aiResult').style.display = 'none';
    document.getElementById('aiLoading').style.display = 'flex';

    try {
        const result = await apiCall('/api/detect-ai', { text });
        renderAIResult(result);
    } catch (error) {
        renderAIError(error.message);
    }
}

function renderAIResult(result) {
    document.getElementById('aiLoading').style.display = 'none';
    const container = document.getElementById('aiResult');
    container.style.display = 'block';

    const prob = result.ai_probability;
    const level = prob >= 55 ? 'high' : prob >= 40 ? 'medium' : 'low';

    // Probability bar
    const barFill = document.getElementById('aiBarFill');
    barFill.className = `ai-bar-fill ${level}`;
    setTimeout(() => {
        barFill.style.setProperty('--fill-width', `${prob}%`);
        barFill.querySelector('::after')?.style;
        // Use a different approach for the animation
        barFill.innerHTML = `<div style="
      height: 100%;
      width: ${prob}%;
      border-radius: 10px;
      background: ${level === 'high' ? 'linear-gradient(90deg, #ef4444, #dc2626)' : level === 'medium' ? 'linear-gradient(90deg, #f59e0b, #ef4444)' : 'linear-gradient(90deg, #22c55e, #06b6d4)'};
      transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);
    "></div>`;
    }, 100);

    // Probability value
    const probValue = document.getElementById('aiProbValue');
    probValue.textContent = `${Math.round(prob)}%`;
    probValue.className = `ai-probability-value ${level}`;

    // Verdict
    const verdict = document.getElementById('aiVerdict');
    const verdictLabels = {
        'likely_human': '✓ Likely Human Written',
        'mixed': '⚠ Mixed Signals',
        'likely_ai': '⚠ Likely AI Generated',
        'ai_generated': '✗ AI Generated',
    };
    verdict.textContent = verdictLabels[result.verdict] || result.verdict;
    verdict.className = `ai-verdict-badge ${result.verdict}`;

    // Key metrics
    const metricsEl = document.getElementById('aiMetrics');
    metricsEl.innerHTML = `
    <div class="metric-card">
      <div class="metric-name">Words</div>
      <div class="metric-value">${result.word_count}</div>
    </div>
    <div class="metric-card">
      <div class="metric-name">Sentences</div>
      <div class="metric-value">${result.sentence_count}</div>
    </div>
    <div class="metric-card">
      <div class="metric-name">Confidence</div>
      <div class="metric-value" style="text-transform: capitalize;">${result.confidence}</div>
    </div>
    <div class="metric-card">
      <div class="metric-name">Processing</div>
      <div class="metric-value">${result.processing_time_ms}ms</div>
    </div>
  `;

    // Signals breakdown
    const signalsEl = document.getElementById('aiSignals');
    signalsEl.innerHTML = '<div style="font-size: 11px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; margin-top: 8px;">Signal Breakdown</div>';

    if (result.signals) {
        for (const signal of result.signals.slice(0, 8)) {
            const scoreClass = signal.score > 55 ? 'ai' : signal.score < 40 ? 'human' : 'neutral';
            const label = signal.score > 55 ? 'AI' : signal.score < 40 ? 'Human' : 'Neutral';

            signalsEl.innerHTML += `
        <div class="signal-item">
          <span class="signal-name">${signal.name}</span>
          <span class="signal-score ${scoreClass}">${signal.score}% ${label}</span>
        </div>
      `;
        }
    }
}

function renderAIError(message) {
    document.getElementById('aiLoading').style.display = 'none';
    const container = document.getElementById('aiResult');
    container.style.display = 'block';

    document.getElementById('aiProbValue').textContent = '!';
    document.getElementById('aiProbValue').className = 'ai-probability-value high';
    document.getElementById('aiVerdict').textContent = 'Error';
    document.getElementById('aiVerdict').className = 'ai-verdict-badge ai_generated';
    document.getElementById('aiMetrics').innerHTML = `
    <div class="metric-card" style="grid-column: 1 / -1;">
      <div class="metric-name">Error</div>
      <div class="metric-desc">${message}</div>
      <div class="metric-desc" style="margin-top: 6px;">Make sure the API server is running: npm start</div>
    </div>
  `;
    document.getElementById('aiSignals').innerHTML = '';
}
