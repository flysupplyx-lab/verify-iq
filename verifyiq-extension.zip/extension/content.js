// VerifyIQ - Content Script
// Displays results from right-click context menu actions as floating toasts

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'AI_RESULT') {
        showAIToast(message.data);
    } else if (message.type === 'AI_ERROR') {
        showErrorToast(message.data.message);
    } else if (message.type === 'EMAIL_RESULT') {
        showEmailToast(message.data);
    } else if (message.type === 'EMAIL_ERROR') {
        showErrorToast(message.data.message);
    }
});

function createToastContainer() {
    let container = document.getElementById('verifyiq-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'verifyiq-toast-container';
        document.body.appendChild(container);
    }
    return container;
}

function showAIToast(result) {
    const container = createToastContainer();
    const prob = result.ai_probability;
    const color = prob >= 55 ? '#ef4444' : prob >= 40 ? '#f59e0b' : '#22c55e';
    const label = prob >= 55 ? 'AI Generated' : prob >= 40 ? 'Mixed Signals' : 'Likely Human';

    const toast = document.createElement('div');
    toast.className = 'verifyiq-toast';
    toast.innerHTML = `
    <div class="verifyiq-toast-header">
      <span class="verifyiq-toast-logo">🛡️ VerifyIQ</span>
      <button class="verifyiq-toast-close" onclick="this.closest('.verifyiq-toast').remove()">✕</button>
    </div>
    <div class="verifyiq-toast-body">
      <div class="verifyiq-toast-score" style="color: ${color}">${Math.round(prob)}%</div>
      <div class="verifyiq-toast-label" style="color: ${color}">${label}</div>
      <div class="verifyiq-toast-detail">${result.word_count} words · ${result.sentence_count} sentences · ${result.confidence} confidence</div>
    </div>
  `;

    container.appendChild(toast);
    setTimeout(() => toast.classList.add('verifyiq-toast-show'), 10);
    setTimeout(() => {
        toast.classList.remove('verifyiq-toast-show');
        setTimeout(() => toast.remove(), 300);
    }, 8000);
}

function showEmailToast(result) {
    const container = createToastContainer();
    const color = result.score >= 80 ? '#22c55e' : result.score >= 60 ? '#f59e0b' : '#ef4444';

    const toast = document.createElement('div');
    toast.className = 'verifyiq-toast';
    toast.innerHTML = `
    <div class="verifyiq-toast-header">
      <span class="verifyiq-toast-logo">🛡️ VerifyIQ</span>
      <button class="verifyiq-toast-close" onclick="this.closest('.verifyiq-toast').remove()">✕</button>
    </div>
    <div class="verifyiq-toast-body">
      <div class="verifyiq-toast-score" style="color: ${color}">${result.score}/100</div>
      <div class="verifyiq-toast-label" style="color: ${color}">${result.verdict}</div>
      <div class="verifyiq-toast-detail">${result.email} · ${result.risk_level} risk</div>
      ${result.risk_factors?.length ? `<div class="verifyiq-toast-factors">${result.risk_factors.map(f => `⚠ ${f}`).join('<br>')}</div>` : ''}
    </div>
  `;

    container.appendChild(toast);
    setTimeout(() => toast.classList.add('verifyiq-toast-show'), 10);
    setTimeout(() => {
        toast.classList.remove('verifyiq-toast-show');
        setTimeout(() => toast.remove(), 300);
    }, 8000);
}

function showErrorToast(message) {
    const container = createToastContainer();
    const toast = document.createElement('div');
    toast.className = 'verifyiq-toast verifyiq-toast-error';
    toast.innerHTML = `
    <div class="verifyiq-toast-header">
      <span class="verifyiq-toast-logo">🛡️ VerifyIQ</span>
      <button class="verifyiq-toast-close" onclick="this.closest('.verifyiq-toast').remove()">✕</button>
    </div>
    <div class="verifyiq-toast-body">
      <div class="verifyiq-toast-label" style="color: #ef4444">Error</div>
      <div class="verifyiq-toast-detail">${message}</div>
    </div>
  `;

    container.appendChild(toast);
    setTimeout(() => toast.classList.add('verifyiq-toast-show'), 10);
    setTimeout(() => {
        toast.classList.remove('verifyiq-toast-show');
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}
