// VerifyIQ - Background Service Worker
// Handles context menu and background tasks

const DEFAULT_API_URL = 'http://localhost:3000';

// Helper: get the current API URL from storage
async function getApiUrl() {
    try {
        const { apiUrl } = await chrome.storage.local.get(['apiUrl']);
        return apiUrl || DEFAULT_API_URL;
    } catch (e) {
        return DEFAULT_API_URL;
    }
}

// Helper: get the current API Key from storage
async function getApiKey() {
    try {
        const { apiKey } = await chrome.storage.local.get(['apiKey']);
        return apiKey || '';
    } catch (e) {
        return '';
    }
}

// Create context menu items on install
chrome.runtime.onInstalled.addListener(() => {
    // Right-click on selected text → AI Detection
    chrome.contextMenus.create({
        id: 'verifyiq-detect-ai',
        title: 'Analyze with VerifyIQ (AI Detection)',
        contexts: ['selection'],
    });

    // Right-click on a link that looks like email
    chrome.contextMenus.create({
        id: 'verifyiq-verify-email',
        title: 'Verify Email with VerifyIQ',
        contexts: ['selection'],
    });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    const apiUrl = await getApiUrl();
    const apiKey = await getApiKey();

    const headers = {
        'Content-Type': 'application/json',
        'X-Source': 'extension',
    };
    if (apiKey) headers['X-Api-Key'] = apiKey;

    if (info.menuItemId === 'verifyiq-detect-ai') {
        const text = info.selectionText;
        if (text && text.length >= 50) {
            try {
                const result = await fetch(`${apiUrl}/api/detect-ai`, {
                    method: 'POST',
                    headers,
                    body: JSON.stringify({ text }),
                }).then(r => r.json());

                chrome.tabs.sendMessage(tab.id, {
                    type: 'AI_RESULT',
                    data: result,
                });
            } catch (error) {
                chrome.tabs.sendMessage(tab.id, {
                    type: 'AI_ERROR',
                    data: { message: 'Could not connect to VerifyIQ server. Check your API URL in extension settings.' },
                });
            }
        } else {
            chrome.tabs.sendMessage(tab.id, {
                type: 'AI_ERROR',
                data: { message: 'Please select at least 50 characters of text.' },
            });
        }
    }

    if (info.menuItemId === 'verifyiq-verify-email') {
        const text = info.selectionText?.trim();
        if (text && text.includes('@')) {
            try {
                const result = await fetch(`${apiUrl}/api/verify-email`, {
                    method: 'POST',
                    headers,
                    body: JSON.stringify({ email: text }),
                }).then(r => r.json());

                chrome.tabs.sendMessage(tab.id, {
                    type: 'EMAIL_RESULT',
                    data: result,
                });
            } catch (error) {
                chrome.tabs.sendMessage(tab.id, {
                    type: 'EMAIL_ERROR',
                    data: { message: 'Could not connect to VerifyIQ server. Check your API URL in extension settings.' },
                });
            }
        }
    }
});
